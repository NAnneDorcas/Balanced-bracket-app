import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BalancedBracketService {
  private apiUrl = 'http://localhost:5012/BracketValidation';

  constructor(private http: HttpClient) { }

  balancedBracket(input: string[]) {
  const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  return this.http.post<{ isBalanced: boolean[] }>(
    `${this.apiUrl}/balanced-bracket`,
    input,
    { headers }
  );
}

}
