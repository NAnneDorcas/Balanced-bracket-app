import { Component,inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { BalancedBracket } from '../../features/balanced-bracket/balanced-bracket';
import { MatDialog } from '@angular/material/dialog';
import { BalancedBracketService } from '../../balanced-bracket.service';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'app-welcome-bracket',
  imports: [MatIconModule,MatInputModule,MatFormFieldModule,FormsModule,MatButtonModule,CommonModule],
  templateUrl: './welcome-bracket.html',
  styleUrl: './welcome-bracket.css',
  standalone: true,
})
export class WelcomeBracket {
  bracketInput: string = "";
  value: string[] = [];
  readonly dialog = inject(MatDialog);
  constructor(private balancedBracketService: BalancedBracketService) {}
  
  checkBalanced() {
  this.value = this.bracketInput.split(',').map(s => s.trim());
  if (this.value.length !== 3) {
    console.error('Exactly 3 input strings are required.');
    return;
  }
  this.balancedBracketService.balancedBracket(this.value).subscribe({
    next: (response)=> {
      // Pass the response data to the dialog
      this.dialog.open(BalancedBracket, {
        data: { isBalanced: response.isBalanced }
      });
    },
    error:(error) => {
      console.error('Error checking balanced brackets:', error);
    }
  });
}

}
