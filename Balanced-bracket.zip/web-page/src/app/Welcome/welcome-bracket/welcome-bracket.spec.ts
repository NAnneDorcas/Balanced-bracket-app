import { TestBed } from '@angular/core/testing';
import { WelcomeBracket } from './welcome-bracket';
import { BalancedBracketService } from '../../balanced-bracket.service';
import { MatDialog } from '@angular/material/dialog';
import { of, throwError } from 'rxjs';

describe('WelcomeBracket', () => {
  let component: WelcomeBracket;
  let mockBalancedBracketService: jest.Mocked<BalancedBracketService>;
  let mockDialog: jest.Mocked<MatDialog>;

  beforeEach(() => {
    mockBalancedBracketService = {
      balancedBracket: jest.fn(),
    } as any;

    mockDialog = {
      open: jest.fn(),
    } as any;

    TestBed.configureTestingModule({
      providers: [
        WelcomeBracket,
        { provide: BalancedBracketService, useValue: mockBalancedBracketService },
        { provide: MatDialog, useValue: mockDialog },
      ],
    });

    component = TestBed.inject(WelcomeBracket);
  });

  it('should call balancedBracket with the current value when checkBalanced is called', () => {
    const response = { isBalanced: true };
    mockBalancedBracketService.balancedBracket.mockReturnValue(of(response));

    component.value = '()[]{}';
    component.checkBalanced();

    expect(mockBalancedBracketService.balancedBracket).toHaveBeenCalledWith('()[]{}');
  });

  it('should open dialog with correct data on successful response', () => {
    const response = { isBalanced: true };
    mockBalancedBracketService.balancedBracket.mockReturnValue(of(response));

    component.checkBalanced();

    expect(mockDialog.open).toHaveBeenCalledWith(expect.any(Function), {
      data: { isBalanced: true },
    });
  });

  it('should handle errors without throwing', () => {
    const error = new Error('test error');
    mockBalancedBracketService.balancedBracket.mockReturnValue(throwError(() => error));
    const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation(() => {});

    component.checkBalanced();

    expect(consoleErrorSpy).toHaveBeenCalledWith('Error checking balanced brackets:', error);

    consoleErrorSpy.mockRestore();
  });
  it('should open dialog with isBalanced false for empty input', () => {
  mockBalancedBracketService.balancedBracket.mockReturnValue(of({ isBalanced: false }));
  component.value = '';

  component.checkBalanced();

  expect(mockBalancedBracketService.balancedBracket).toHaveBeenCalledWith('');
  expect(mockDialog.open).toHaveBeenCalledWith(expect.any(Function), { data: { isBalanced: false } });
});
it('should open dialog with isBalanced false for empty input', () => {
    mockBalancedBracketService.balancedBracket.mockReturnValue(of({ isBalanced: false }));
    component.value = '';

    component.checkBalanced();

    expect(mockBalancedBracketService.balancedBracket)
      .toHaveBeenCalledWith('');
    expect(mockDialog.open)
      .toHaveBeenCalledWith(expect.any(Function), { data: { isBalanced: false } });
  });

});
