import { ComponentFixture, TestBed } from '@angular/core/testing';
import { WelcomeDialog } from './welcome-dialog';
import { TranslateModule,TranslateService } from '@ngx-translate/core';
import { Dialog } from '../../features/dialog/dialog';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

describe('WelcomeDialog', () => {
  let component: WelcomeDialog;
  let fixture: ComponentFixture<WelcomeDialog>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [WelcomeDialog,TranslateModule.forRoot(),NoopAnimationsModule]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WelcomeDialog);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should render translated header', () => {
    fixture.detectChanges();
    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.querySelector('h3')?.textContent).toContain('WELCOME.HEADER');
  });
  it('should set default language to be english', () => {
    const app = fixture.componentInstance;
    expect(app.language).toBe('en');
  });

  it('should open dialog when openDialog is called', () => {
  const dialogSpy = jest.spyOn(component['dialog'], 'open');
  component.openDialog();
  expect(dialogSpy).toHaveBeenCalledWith(Dialog);
});

  it('should change language and call translate.use', () => {
  const component = fixture.componentInstance;
  const translateService = TestBed.inject(TranslateService);
  const useSpy = jest.spyOn(translateService, 'use');

  component.changeLanguage('ee');

  expect(component.language).toBe('ee');
  expect(useSpy).toHaveBeenCalledWith('ee');

});
});
