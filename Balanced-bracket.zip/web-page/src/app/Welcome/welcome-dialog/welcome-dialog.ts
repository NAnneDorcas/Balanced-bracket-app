
import { Component, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { Dialog } from '../../features/dialog/dialog';

@Component({
  selector: 'app-welcome-dialog',
  imports: [MatDialogModule,MatButtonModule,TranslateModule,MatSelectModule,MatFormFieldModule],
  templateUrl: './welcome-dialog.html',
  styleUrl: './welcome-dialog.css',
  standalone: true,
})
export class WelcomeDialog {
  language = 'en';
  readonly dialog = inject(MatDialog);
  private translate = inject(TranslateService);

  constructor() {
    // const savedLang = localStorage.getItem('appLanguage');
    // this.language = savedLang ?? ''; saves the langage choosen after refresh of page
    this.translate.setDefaultLang('en');
    this.translate.use(this.language);
  }
  
  openDialog():void{
    this.dialog.open(Dialog);
  
  }

  changeLanguage(lang: string) {
    
    this.language = lang;
    // localStorage.setItem('appLanguage', lang);
    this.translate.use(lang);
  }
}
