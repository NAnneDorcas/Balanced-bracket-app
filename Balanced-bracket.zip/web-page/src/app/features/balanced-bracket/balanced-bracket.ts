
import { CommonModule } from '@angular/common';
import { Component,inject} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogActions, MatDialogClose, MatDialogContent, MatDialogModule } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
@Component({
  selector: 'app-balanced-bracket',
  imports: [MatDialogModule,MatDialogActions,MatDialogContent,MatDialogClose,MatButtonModule,CommonModule],
  templateUrl: './balanced-bracket.html',
  standalone: true,
  styleUrl: './balanced-bracket.css'
})
export class BalancedBracket {
  data = inject(MAT_DIALOG_DATA) as { isBalanced: boolean[] };
  
}
