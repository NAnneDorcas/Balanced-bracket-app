import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { BalancedBracket } from './balanced-bracket';

describe('BalancedBracket', () => {
  let component: BalancedBracket;
  let fixture: ComponentFixture<BalancedBracket>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BalancedBracket],
      providers: [
        { provide: MAT_DIALOG_DATA, useValue: { isBalanced: true } }
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BalancedBracket);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should display balanced status correctly', () => {
    const compiled = fixture.nativeElement as HTMLElement;
    // Adjust selector based on your template content
    expect(compiled.textContent).toContain('balanced');
  });
});
