import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { BalancedBracketService } from './balanced-bracket.service';

describe('BalancedBracketService', () => {
  let service: BalancedBracketService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [BalancedBracketService]
    });

    service = TestBed.inject(BalancedBracketService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should call POST and return isBalanced', () => {
    const inputString = '()[]{}';
    const mockResponse = { isBalanced: true };

    service.balancedBracket(inputString).subscribe(response => {
      expect(response.isBalanced).toBe(true);
    });

    const req = httpMock.expectOne(service['apiUrl']);
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({ input: inputString });

    req.flush(mockResponse);
  });
});
