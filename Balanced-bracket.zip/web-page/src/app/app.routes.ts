import { Routes } from '@angular/router';
import { WelcomeDialog } from './Welcome/welcome-dialog/welcome-dialog';
import { WelcomeBracket } from './Welcome/welcome-bracket/welcome-bracket';



export const routes: Routes = [
    {
        path:"",
        redirectTo:"welcome-dialog",
        pathMatch:"full"
    },
    {path:'welcome-dialog',
        component:WelcomeDialog
    },
    {path:'welcome-bracket',
        component:WelcomeBracket
    },
    
];
